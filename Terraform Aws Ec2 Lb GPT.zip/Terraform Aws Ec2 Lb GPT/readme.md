# Terraform Configuration for AWS Web Application Deployment

This repository contains Terraform configurations for deploying a web application on AWS using EC2 instances, a VPC, subnets, a load balancer, and security groups. The setup includes separate frontend and backend components with a well-structured network design.

## Features
- Custom **VPC** with public and private subnets.
- **Internet Gateway** and appropriate route tables for public and private routing.
- **Frontend and Backend EC2 Instances** deployed in separate subnets.
- An **Application Load Balancer (ALB)** for frontend traffic distribution.
- Configurable **Security Groups** for secure traffic management.

## Architecture Overview
1. A VPC (`10.0.0.0/16`) is created with two subnets:
   - `frontend_subnet`: Public subnet for the frontend instance and load balancer.
   - `backend_subnet`: Private subnet for backend services.
2. The load balancer routes HTTP traffic to the frontend EC2 instance.
3. The frontend EC2 instance communicates securely with the backend instance.
4. Security groups ensure traffic isolation and controlled access.

## Prerequisites
1. **Terraform** installed on your local machine.
2. AWS account with access to manage resources.
3. IAM user with sufficient permissions for EC2, VPC, and Load Balancer operations.
4. Configured AWS credentials (`~/.aws/credentials`).

## Usage

### Step 1: Clone the Repository
```bash
git clone <repository-url>
cd <repository-directory>
```

### Step 2: Initialize Terraform
```bash
terraform init
```

### Step 3: Preview the Plan
```bash
terraform plan
```
This will show the resources that will be created or modified.

### Step 4: Apply the Configuration
```bash
terraform apply
```
Type `yes` when prompted to confirm the changes.

### Step 5: Access the Web Application
After the deployment, the DNS of the Load Balancer will be displayed as an output. Use it to access the frontend application:
```bash
frontend_lb_dns = <load-balancer-dns>
```

## Outputs
- **Frontend Load Balancer DNS:** The DNS name for accessing the frontend application.

## Clean Up
To delete all created resources, run:
```bash
terraform destroy
```
Type `yes` to confirm the deletion.

## File Structure
```
|-- main.tf               # Main Terraform configuration file
|-- variables.tf          # Variables used in the configuration
|-- outputs.tf            # Outputs configuration
|-- README.md             # Documentation file (this file)
```

## Notes
- Ensure the selected AWS region supports the resources used in this configuration.
- Update the AMI ID in the configuration to match your preferred Linux distribution.
- Adjust instance types and CIDR blocks based on your use case.

## License
This project is licensed under the MIT License. See the LICENSE file for details.

---

Happy Deploying!

